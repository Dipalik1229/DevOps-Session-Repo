#!/bin/bash
if [ $(whoami) = "root" ]
then
    echo "You are root user"
else
    echo "You are  normal user"
fi