#!/bin/bash
echo "welcome to shell Scripting! by Dipali Kshirsagar"
echo "User: $(whoami)"
echo "Date: $(date)"
echo "Uptime: $(uptime -p)"
echo "List of files:$(ls)"
chmod +x first.sh