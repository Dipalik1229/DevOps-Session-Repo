#!/bin/bash
SOURCE_DIR="/mnt/c/Users/user/OneDrive/Desktop/Devops_session"
BACKUP_DIR="/mnt/c/Users/user/OneDrive/Desktop/Backup"

mkdir -p "$BACKUP_DIR"

TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)

BACKUP_NAME="backup_$TIMESTAMP.tar.gz"

tar -czf "$BACKUP_DIR/$BACKUP_NAME" "$SOURCE_DIR"

echo "✅ Backup Completed : $BACKUP_DIR/$BACKUP_NAME"

