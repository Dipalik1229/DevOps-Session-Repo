#!/bin/bash
name="Dipali"
echo "Hello, $name! Welcome to DevOps Training."