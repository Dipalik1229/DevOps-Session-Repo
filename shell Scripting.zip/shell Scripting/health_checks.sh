#!/bin/bash
REPORT="/mnt/c/Users/user/OneDrive/Desktop/Devops_session/shell Scripting/System_health_$(date +%Y-%m-%d).txt"
{
    echo "✅ System Health Report - $(date)"
    echo "User: $(whoami)"
    echo "Uptime: $(uptime -p)"
    echo "CPU Load: $(top -bn1 | grep 'load average' | awk '{print $10 $11 $12}')"
    echo "Memory Usage:"
    free -h
    echo "Disk Usage:"
    df -h | grep '/dev'

} > "$REPORT"
echo "✅ Report Saved to  $REPORT"