from flask import Flask, render_template_string

app = Flask(__name__)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Flask Calculator</title>
    <style>
        body {
            background: url('https://static.vecteezy.com/system/resources/previews/049/976/216/non_2x/university-graduation-hat-diploma-on-simple-background-study-year-academic-success-student-achievement-celebration-college-cap-academy-bachelor-master-degree-phd-award-study-studying-photo.jpg')
                        no-repeat center center fixed;
            background-size: cover;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
            color: white;
            margin: 0;
        }

        header {
            margin-top: 25px;
            font-size: 30px;
            font-weight: bold;
            text-shadow: 1px 1px 5px rgba(0,0,0,0.6);
        }

        .calculator {
            background: rgba(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
            width: 90%;
            max-width: 330px;
            margin: 20px auto;
        }

        input {
            width: 100%;
            height: 55px;
            font-size: 22px;
            text-align: right;
            margin-bottom: 15px;
            padding: 10px;
            border: none;
            border-radius: 8px;
            background-color: #f3f3f3;
            box-sizing: border-box;
        }

        .buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }

        button {
            height: 55px;
            font-size: 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            background-color: #e0e0e0;
            transition: 0.2s;
        }

        button:hover {
            background-color: #d4d4d4;
        }

        .operator {
            background-color: #0078ff;
            color: white;
        }

        .operator:hover {
            background-color: #005fcc;
        }

        .equals {
            background-color: #28a745;
            color: white;
        }

        .equals:hover {
            background-color: #218838;
        }

        .clear {
            background-color: #dc3545;
            color: white;
        }

        .clear:hover {
            background-color: #c82333;
        }

        footer {
            width: 100%;
            text-align: right;
            padding: 12px 30px;
            font-size: 20px;
            color: black;
            font-style: italic;
            letter-spacing: 0.6px;
            text-shadow: 1px 1px 3px rgba(255,255,255,0.5);
            box-sizing: border-box;
        }

        @media (max-width: 600px) {
            header {
                font-size: 24px;
            }
            .calculator {
                max-width: 280px;
            }
            footer {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <header>🧮 Flask Calculator</header>

    <div class="calculator">
        <input type="text" id="display" readonly>
        <div class="buttons">
            <button class="clear" onclick="clearDisplay()">C</button>
            <button onclick="appendValue('(')">(</button>
            <button onclick="appendValue(')')">)</button>
            <button class="operator" onclick="appendValue('/')">÷</button>

            <button onclick="appendValue('7')">7</button>
            <button onclick="appendValue('8')">8</button>
            <button onclick="appendValue('9')">9</button>
            <button class="operator" onclick="appendValue('*')">×</button>

            <button onclick="appendValue('4')">4</button>
            <button onclick="appendValue('5')">5</button>
            <button onclick="appendValue('6')">6</button>
            <button class="operator" onclick="appendValue('-')">−</button>

            <button onclick="appendValue('1')">1</button>
            <button onclick="appendValue('2')">2</button>
            <button onclick="appendValue('3')">3</button>
            <button class="operator" onclick="appendValue('+')">+</button>

            <button onclick="appendValue('0')">0</button>
            <button onclick="appendValue('.')">.</button>
            <button class="equals" onclick="calculateResult()">=</button>
        </div>
    </div>

    <footer>🧮✅Calculator Created by Dipali Kshirsagar🥳✨</footer>

    <script>
        const display = document.getElementById("display");

        function appendValue(value) {
            display.value += value;
        }

        function clearDisplay() {
            display.value = "";
        }

        function calculateResult() {
            try {
                display.value = eval(display.value);
            } catch (error) {
                display.value = "Error";
            }
        }
    </script>
</body>
</html>
"""

@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=2025)
